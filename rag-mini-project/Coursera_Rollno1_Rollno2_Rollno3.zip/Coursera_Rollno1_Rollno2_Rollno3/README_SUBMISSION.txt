Submission layout
1_Project_Report  2_Dataset_Knowledge_Base  3_Document_Processing_Module  4_Embedding_Vector_Database
5_LLM_Prompt_Engineering  6_Testing_Evaluation  7_Source_Code_and_README (start with README.md)
Names / roll numbers are placeholders until docs/team_info.json is completed.
